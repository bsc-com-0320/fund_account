export class CreateFundAccountDto {}
