export class FundAccount {}
